package Exercise2;

/**
 * EquationReverser.java
 * Name: Zeynep Ece Özaslan
 * Student ID: 25044039
 * Date: 26.10.2026
 */

public class EquationReverser {

    // The method is static because it can be called directly without instantiating EquationReverser object
    public static String reverseEquation(String equation) {
        TokenStack stack = new TokenStack();
        int i = 0;
        int n = equation.length();

        // Traverse the equation from left to right
        while (i < n) {
            char current = equation.charAt(i);

            // If the current character is a digit, extract the whole number and push it
            if (Character.isDigit(current)) {
                int start = i;
                // Move forward until the number ends
                while (i < n && Character.isDigit(equation.charAt(i))) {
                    i++;
                }
                String number = equation.substring(start, i);
                stack.push(number);
            }
            // Otherwise (it's an operator), push the operator as a String
            else {
                stack.push(String.valueOf(current));
                i++;
            }
        }

        // Pop all items from the stack and append them to a StringBuilder
        StringBuilder result = new StringBuilder();
        while (!stack.isEmpty()) {
            result.append(stack.pop());
        }

        return result.toString();
    }
}