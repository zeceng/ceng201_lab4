package Exercise2;

/**
 * TokenStack.java
 * Name: Zeynep Ece Özaslan
 * Student ID: 25044039
 * Date: 26.10.2026
 */

public class TokenStack {

    private class Node {
        // Creating the instance named data as a String type
        String data;
        // Creating the next pointer used for Stack implementation as a Node type
        Node next;

        // Completing the constructor accordingly
        Node(String data) {
            this.data = data;
            this.next = null;
        }
    }

    // Creating the top pointer used for Stack implementation as private
    private Node top;

    public TokenStack() {
        // Constructor that assigns the top pointer to null
        top = null;
    }

    public void push(String value) {
        // Creating a new node, connect it to the current top, and update top
        Node newNode = new Node(value);
        newNode.next = top;
        top = newNode;
    }

    public String pop() {
        // Check whether the stack is empty
        if (isEmpty()) {
            return null;
        }
        // Store the top value, move top to the next node, and return the stored value
        String storedValue = top.data;
        top = top.next;
        return storedValue;
    }

    public boolean isEmpty() {
        // Return whether the stack is empty
        return top == null;
    }
}