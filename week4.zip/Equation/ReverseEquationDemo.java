package Exercise2;

/**
 * ReverseEquationDemo.java
 * Name: Zeynep Ece Özaslan
 */

public class ReverseEquationDemo {

    public static void main(String[] args) {

        String[] equations = {
                "20-3+5*2",
                "5+2*56-2/4",
                "123+45*6",
                "100/25-7"
        };

        System.out.println("========== REVERSE EQUATION TEST ==========");
        for (String eq : equations) {
            String output = EquationReverser.reverseEquation(eq);
            System.out.println("Input:  " + eq);
            System.out.println("Output: " + output);
            System.out.println();
        }
    }
}