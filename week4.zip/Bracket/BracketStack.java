package Exercise1;

/**
 * BracketStack.java
 * Name: Zeynep Ece Özaslan
 * Student ID: 25044039
 * Date: 26.10.2026
 */

public class BracketStack {

    private class Node {
        char data;
        Node next;

        Node(char data) {
            this.data = data;
            this.next = null;
        }
    }

    private Node top;

    public BracketStack() {
        top = null;
    }

    //add an element to the top of the stack
    public void push(char value) {
        // Create a new node and connect it to the current top
        Node newNode = new Node(value);
        newNode.next = top;
        top = newNode;
    }

    //remove and return the top element
    public char pop() {
        if (isEmpty()) {
            return '\0';
        }
        //save the top data, then update top to the next node
        char poppedData = top.data;
        top = top.next;
        return poppedData;
    }

    //return the top element without removing it
    public char peek() {
        // control if the stack is empty; if it is, return null character
        if (isEmpty()) {
            return '\0';
        }
        // return the data of the top node
        return top.data;
    }

    // check whether the stack is empty
    public boolean isEmpty() {
        // Return true if top is null, otherwise false
        return top == null;
    }
}
